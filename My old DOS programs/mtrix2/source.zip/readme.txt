                    Recompiling the Source Code                         
                    ----------------------------
     
     If you want to customise or improve the source code of Matrix you 
     are free to do so. Don't worry if you accidentally messing it up. 
     You can make a backup copy of the source beforehand.
     
     To compile this project you will need either one of Borland's two 
     compilers, Turbo C++ 3.0 or Borland's windows version, C++ 4.5; you
     will also need Borland's Tasm assembler, version 5.
     
     Uncompress all the files in the source.zip archive to a folder. 
     Rename the folder Matrix, then copy it to drive D (assuming you 
     have two hard drives or one partitioned hard drive). Then load up 
     Turbo C++ 3.0 and locate the directory d:\matrix then load in the 
     "matrix.prj" file. From the Options menu in the IDE turn on "debug 
     info in objs" and make sure the compiler's source debugging set to 
     on. As a test try recompiling the project just to make sure every 
     works ok.
     
     If you want to add extra functions to the parser you only need to 
     modify parse.cpp, and parse2.cpp. Add the new function prototypes 
     to the parse.h header file. Add the name of each function to the 
     function list string which begins about line 286 of parse.cpp. Then
     add your function at the bottom in the big switch statement in 
     function atom. Then go to the parse2.cpp file and add your function
     to the bottom of the file. In order to do this you should study the
     functions that are already there and follow the same example. You 
     can step through the execution of any of the functions, and examine
     variables using the built-in debugger of Turbo 3.0. 
     --------------------------------------------------------------- 
     M.F. 
     18 Feb 2000
     
      
